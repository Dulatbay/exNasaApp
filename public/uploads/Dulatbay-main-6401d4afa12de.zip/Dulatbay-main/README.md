- 👋 Hi, I’m Dulatbay Akhan
- 🌱 I’m currently learning pyton/java/react/vue
- 📫 How to reach me adulatbai@bk.ru akhan.dulatbay@gmail.com

